#include<stdio.h>
int main(){
double a,b;
scanf("%lf%lf",&a,&b);

printf("\nOUTPUT:\n%0.4lf",(a*a+b*b)/2);




return 0;
}