#include<stdio.h>
int main(){
 double x,y;
 scanf("%lf%lf",&x,&y);
 printf("\nOUTPUT:\n%0.4lf",2*x*x+3*y+4);








return 0;
}